package pl.bialek.infrastructure.database.entity;

public interface _EntityMarker {
}
