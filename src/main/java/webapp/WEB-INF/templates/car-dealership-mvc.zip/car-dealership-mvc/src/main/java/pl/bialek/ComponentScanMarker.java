package pl.bialek;

public interface ComponentScanMarker {
}
