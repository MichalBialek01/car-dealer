package pl.bialek.infrastructure.database.repository.jpa;

public interface _JpaMarker {
}
